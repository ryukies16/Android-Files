package com.LABEXAM;


import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;




public class nextjava extends Activity
{
	 TextView txt1,txt2,txt3,txt4,txt5,txt6,txt7   ;
	String st1,st2,st3,st4;
	
	
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.nextpage);
				txt1=findViewById(R.id.nextedtxt1);
				st1 =getIntent().getExtras().getString("Value");
				txt1.setText(st1);
				txt2=findViewById(R.id.nexttxt2);
				st2 =getIntent().getExtras().getString("Value");
				txt2.setText(st2);
				
				txt3=findViewById(R.id.nexttxt3);
				st3 =getIntent().getExtras().getString("Value");
				txt3.setText(st3);
				
				txt4 =findViewById(R.id.nntxt1);
		      
				
				
				txt5 =findViewById(R.id.nntxt2);
				txt6 =findViewById(R.id.nntxt3);
				txt7 =findViewById(R.id.nntxt4);
				
}
}
