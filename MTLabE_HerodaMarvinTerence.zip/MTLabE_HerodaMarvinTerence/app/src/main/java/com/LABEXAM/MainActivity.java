package com.LABEXAM;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;

public class MainActivity extends Activity 
{
	CheckBox c1,c2,c3,c4;
	Button sub,reset;
	RadioButton r1,r2;
	EditText ed1,ed2,ed3,ed4;
	String st3,st1,st2,st4,st5,st6,st7,st8;
	Intent intentdata;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		c1 = findViewById(R.id.cbox1);
		c2 = findViewById(R.id.cbox2);
		c3 = findViewById(R.id.cbox3);
		c4 = findViewById(R.id.cbox4);
		sub = findViewById(R.id.btnsubmit);
		reset = findViewById(R.id.btnreset);
		r1 = findViewById(R.id.rbox1);
		r2 = findViewById(R.id.rbox2);
		
		ed1 = findViewById(R.id.edtxt1);
		ed2 = findViewById(R.id.edtxt2);
		ed3 = findViewById(R.id.edtxt3);
		ed4 = findViewById(R.id.edtxt4);
		intentdata = new Intent(MainActivity.this,nextjava.class);
		
		
		
		sub.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1)
						{
							Intent submit =new Intent(MainActivity.this,nextjava.class)       ;
							st1 = ed1.getText().toString();
							submit.putExtra("Value",st1);
							st2 = ed2.getText().toString();
							submit.putExtra("Value",st2);
							st3 = ed3.getText().toString();
							submit.putExtra("Value",st3);
							st4 = ed4.getText().toString();
							submit.putExtra("Value",st4);
							startActivity(submit);
							finish();

						
							
							
							
							if(c1.isChecked()){
								intentdata.putExtra("one","30.00");
							}
							else
							{
								intentdata.removeExtra("one");
							}
							
							if(c2.isChecked()){
									intentdata.putExtra("one","50.00");
								}
							else
								{
									intentdata.removeExtra("one");
								

								}
							if(c3.isChecked()){
									intentdata.putExtra("one","35.00");
								}
							else
								{
									intentdata.removeExtra("one");


								

								}
							if(c4.isChecked()){
									intentdata.putExtra("one","20.00");
								}
							else
								{
									intentdata.removeExtra("one");


								}

								}
							

			
		});
		
		
		
		
    
		
	}
	
}
