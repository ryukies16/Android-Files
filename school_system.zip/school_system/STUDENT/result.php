<?php include 'student_header.php'; 
include '../database.php';
session_start();






?>

<div class="container">
	<div class="card">
		<div class="card-body">
		<table class="table table-bordered">
			<tr>
				<th>COURSE ID</th>
				<th>COURSE NAME</th>
				<th>QUIZ 1</th>
				<th>QUIZ 2</th>
				<th>EXAM</th>
				<th>TOTAL</th>
				<th>GRADE</th>

			</tr>
<?php 

$student_id = $_SESSION['student_id'];

$query = "SELECT course_id,course.name as cname,quiz1,quiz2,exams,(quiz1+quiz2+exams)as Total, grade FROM results,course WHERE results.course_id =course.id AND student_id = '$student_id' ";

$result = mysqli_query($connection,$query);

while ($rows = mysqli_fetch_assoc($result)) {
	


 ?>

	<tr>
		<td><?php echo $rows['course_id']; ?></td>
		<td><?php echo $rows['cname']; ?></td>
		<td><?php echo $rows['quiz1']; ?></td>
		<td><?php echo $rows['quiz2']; ?></td>
		<td><?php echo $rows['exams']; ?></td>
		<td><?php echo $rows['Total']; ?></td>
		<td>
<?php 

$score = $rows['Total'];

if ($score >=95) {
	echo "A";
}
elseif ($score >= 90) {
	echo "B";
}
elseif ($score >= 85) {
	echo "C";
}
elseif ($score >= 80) {
	echo "D";
}
elseif ($score >= 75) {
	echo "E";
}
else{
	echo "F";
}




 ?>			

		</td>
				
			</tr>
<?php } ?>

			</table>

		</div>
	</div>
	

</div>