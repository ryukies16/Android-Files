<?php include 'student_header.php'; 
include '../database.php';
session_start();


if (isset($_GET['course_id'])&&isset($_GET['teacher_id'])&&isset($_GET['student_id'])) {
	
$course_id = $_GET['course_id'];
$teacher_id = $_GET['teacher_id'];
$student_id = $_GET['student_id'];

$query = "INSERT INTO `results`( `course_id`, `teacher_id`, `student_id`, `quiz1`, `quiz2`, `exams`, `grade`) VALUES ('$course_id','$teacher_id','$student_id','0','0','0','Not graded')";

$result = mysqli_query($connection,$query);

if ($result) {

echo "<script> alert('Successful Register')</script>";

}

}








?>


<div class="container">
	<div class="card mt-5">
		<div class="card-header" align="center">
<h4>COURSES AVAILABLE</h4>
		</div>
			<div class="card-body">
<table class="table">
	<tr>
		<th>COURSE ID</th>
		<th>COURSE NAME</th>
		<th>TEACHER NAME</th>
		<th>ACTION</th>

	</tr>
<?php 

$student_id = $_SESSION['student_id'];

$query ="SELECT course.name as cname,teacher.First_Name as tfistname,assign_course.course_id as cid,assign_course.teacher_id as tid FROM teacher,course,assign_course WHERE teacher.id=assign_course.teacher_id AND course.id = assign_course.course_id";

$result = mysqli_query($connection,$query);

while ($rows = mysqli_fetch_assoc($result)) {
	# code...


 ?>


	<tr>
		<td><?php echo $rows['cid'] ?></td>
		<td><?php echo $rows['cname']; ?></td>
		<td><?php echo $rows['tfistname']; ?></td>
		<td><a href="register.php?course_id= <?php echo $rows['cid'] ?>&teacher_id=<?php echo $rows['tid'] ?>&student_id=<?php echo $student_id ?>">Register</a></td>
	</tr>

	<?php } ?>

</table>
				
			</div>

		

	</div>


</div>