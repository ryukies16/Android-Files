<?php 


$servename = "localhost";
$username = "root";
$password = "";
$dbname = "school_system";

$connection = mysqli_connect($servename,$username,$password,$dbname);








 ?>