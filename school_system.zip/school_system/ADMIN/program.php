<?php include('admin_header.php') ?>
<?php 
include '../database.php';

if (isset($_POST['submit'])) {
  $program_name = $_POST['Pname'];

  $query1 = "INSERT INTO `program`( `name`) VALUES ('$program_name')";

  $result1 = mysqli_query($connection,$query1);
  echo "<script>alert('Data Was Insert')</script>";
}


if (isset($_GET['delete_id'])) {
  
$delete_id = $_GET['delete_id'];

$query3 = "DELETE FROM `program` WHERE `id` ='$delete_id'";

$result3 = mysqli_query($connection,$query3);







}


 ?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>School System</title>
  </head>
  <body>
    

    <div class="container">
      <div class="card mt-5 p-4">
        <div class="card-body">
          <form class="form-group" method="POST" action="#">
            <label>PROGRAM NAME</label>
            <input type="text" name="Pname" class="form-control" required="true">
            <input type="submit" name="submit" class="btn btn-success mt-4" value="ADD SUBJECT">
          </form>

        </div>

      </div>
 
 <table class="table table-hover mt-3">
  <tr>
    <th>ID</th>
    <th>SUBJECT</th>
    <th>ACTION</th>
  </tr>
   <?php 
$query2 = "SELECT * FROM `program`";
$result2 = mysqli_query($connection,$query2);

while ($rows = mysqli_fetch_assoc($result2)) {
  



    ?>
   <tr>
     <td><?php echo $rows['id']; ?></td>
     <td><?php echo $rows['name']; ?></td>
     <td><a href="program.php?delete_id=<?php echo $rows['id'] ?>"><button class="btn btn-danger">DELETE</button></a></td>
   </tr>

<?php } ?>
 </table>



    </div>

    

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
  </body>
</html>