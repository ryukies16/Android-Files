<?php include ('admin_header.php'); ?>

<?php 

include '../database.php';

if (isset($_POST['submit'])) {
	
	$coursename = $_POST['Cname'];

	$query = "INSERT INTO `course`(`name`) VALUES ('$coursename')";
	$result = mysqli_query($connection,$query);

	echo "<script>alert('Success')</script>";
}

if (isset($_GET['delete_id'])) {
  
$delete_id = $_GET['delete_id'];

$query3 = "DELETE FROM `course` WHERE `id` ='$delete_id'";

$result3 = mysqli_query($connection,$query3);

}
 ?>


    <div class="container">
      <div class="card mt-5 p-4">
        <div class="card-body">
          <form class="form-group" method="POST" action="#">
            <label>COURSE NAME</label>
            <input type="text" name="Cname" class="form-control" required="true">
            <input type="submit" name="submit" class="btn btn-success mt-4" value="ADD COURSE">
          </form>

        </div>

      </div>

      <table class="table table-hover mt-3">
        <tr>
          <th>ID</th>
          <th>COURSE</th>
          <th>ACTION</th>
        </tr>

<?php 
$query2 = "SELECT * FROM `course`";
$result2 = mysqli_query($connection,$query2);

while ($rows = mysqli_fetch_assoc($result2)) {
  



 ?>
        <tr>
          <td><?php echo $rows['id']; ?></td>
          <td><?php echo $rows['name']; ?></td>
          <td><a href="course.php?delete_id=<?php echo $rows['id']; ?>"><button class="btn btn-danger ">DELETE</button></a></td>

        </tr>
<?php } ?>

      </table>

    </div>