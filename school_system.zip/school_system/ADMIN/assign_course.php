<?php include 'admin_header.php'; ?>

<?php 
include '../database.php';

if (isset($_POST['submit'])) {

$teacher_id = $_POST['teacher_id'];
$course_id = $_POST['course_id'];

$query = "INSERT INTO `assign_course`( `teacher_id`, `course_id`) VALUES ('$teacher_id','$course_id')";
$result = mysqli_query($connection,$query);

echo "<script>alert('Success')</script>";

}


 ?>
    <div class="container">
      <div class="card mt-5 p-4">
        <div class="card-body">
          <form class="form-group" method="POST" action="#">
            <label>TEACHER NAME</label>
            <select name="teacher_id" class="form-control">
<?php 
$query2 = "SELECT * FROM `teacher`";
$result2 = mysqli_query($connection,$query2);

while ($rows = mysqli_fetch_assoc($result2)) {
	


 ?>

            	<option value="<?php echo $rows['id'] ?>"><?php echo $rows['First_Name'] .'   ' .$rows['Last-Name']; ?></option>
          <?php  } ?>  	
            </select>

            <label class="mt-3">COURSE TITLE</label>
            <select name="course_id" class="form-control">
 <?php 
$query3 = "SELECT * FROM `program`";
$result3 = mysqli_query($connection,$query3);

while ($rows3 = mysqli_fetch_assoc($result3)) {
	

  ?>
            <option value="<?php echo $rows3['id'];  ?>"><?php echo $rows3['name']; ?></option>
            <?php  } ?>
            </select>
            <input type="submit" name="submit" class="btn btn-success mt-4" value="ASSIGN COURSE">
          </form>

        </div>

      </div>
      </div>