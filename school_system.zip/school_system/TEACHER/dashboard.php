<?php 
include 'teacher_header.php';
include '../database.php';

 ?>

 <?php 
if (isset($_POST['update'])) {
	
	$student_id = $_POST['student_id'];
	$course_id = $_POST['course_id'];
	$quiz1 = $_POST['quiz1'];
	$quiz2 = $_POST['quiz2'];
	$exams = $_POST['exams'];
	

$query2 = "UPDATE `results` SET `quiz1`='$quiz1',`quiz2`='$quiz2',`exams`='$exams' WHERE  `student_id` ='$student_id' AND  `course_id` = '$course_id'  ";

$result2 = mysqli_query($connection,$query2);

echo "<script>alert('Successful Update')</script>";


}

  ?>

 <div class="containter">
 	<div class="card">
 		<div class="card-body">
 			
<table class="table">
	<tr>
		<td>STUDENT ID</td>
		<td>STUDENT NAME</td>
		<td>COURSE ID</td>
		<td>COURSE NAME</td>
		<td>QUIZ 1</td>
		<td>QUIZ 2</td>
		<td>EXAM</td>
		<td>ACTION</td>

	</tr>

	<?php 

$query = "SELECT student_id,student.firstname as firstname,student.lastname as lastname,course_id,course.name as cname,quiz1,quiz2,exams FROM results,course,student WHERE results.course_id = course.id AND results.student_id = student.id";

$result = mysqli_query($connection,$query);

while ($rows = mysqli_fetch_assoc($result)) {
	# code...


	 ?>

		<tr>
			<td><?php echo $rows['student_id']; ?></td>
			<td><?php echo $rows['firstname'].''.$rows['lastname']; ?></td>
			<td><?php echo $rows['course_id']; ?></td>
			<td><?php echo $rows['cname']; ?></td>
			<form class="form-group" method="POST" action="#">
			<input type="hidden" name="student_id" value="<?php echo $rows['student_id']; ?>">
			<input type="hidden" name="course_id" value="<?php echo $rows['course_id']; ?>">
			<td> <input  class="form-control" type="number" name="quiz1" min="0" max="25" value="<?php echo $rows['quiz1'] ?>"></td>
			<td><input class="form-control" type="number" name="quiz2" min="0" max="25" value="<?php echo $rows['quiz2'] ?>"></td>
			<td><input class="form-control" type="number" name="exams" min="0" max="50" value="<?php echo $rows['exams'] ?>"></td>
			<td><input class="btn btn-success" type="submit" name="update" value="UPDATE" ></td>
			</form>
			

		</tr>
	<?php } ?>

</table>


 		</div>

 	</div>


 </div>