package com.BmICALCU;
import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.content.Intent;

public class admin extends Activity
{
	Button baddstud,bvstud,battperstud,btnaddfacu,btnvfacu,btnlogout;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.admin);
		
		Button baddstud =findViewById(R.id.btnadstudent);
		Button bvstud =findViewById(R.id.btnvstudent);
		Button battperstud =findViewById(R.id.btnAttperstud);
		Button btnaddfacu =findViewById(R.id.btnaddfaculty);
		Button btnvfacu =findViewById(R.id.btnvfaculty);
		Button btnlogout =findViewById(R.id.btnlogout);
		
		btnaddfacu.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
				Intent intent = new Intent(admin.this,facultyreg.class);
				startActivity(intent);
				}
				
			
		});
		
		btnvfacu.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{

					Intent intent = new Intent(admin.this,faculy_list.class);
					startActivity(intent);
				}


			});
			
		btnlogout.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{

					Intent intent = new Intent(admin.this,MainActivity.class);
					startActivity(intent);
				}


			});
			
		baddstud.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent(admin.this,studentreg.class);
					startActivity(intent);
				}
				


			});
			
		bvstud.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent(admin.this,viewstud.class);
					startActivity(intent);
				}



			});
			
		
	}

}

