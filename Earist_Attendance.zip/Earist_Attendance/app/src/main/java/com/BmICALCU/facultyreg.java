package com.BmICALCU;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.content.Context;

public class facultyreg extends Activity
{
	Button btnsub,btncancel;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.faculty_reg);
		
		Button btnsub=findViewById(R.id.btnsubmit);
		Button btncancel=findViewById(R.id.btncancel)                                ;
		
		btncancel.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent(facultyreg.this,admin.class);
					startActivity(intent);
				}


			});
	
		
}
       public void Onsubmit (View view){
		   Toast.makeText(this,"Success Input",Toast.LENGTH_LONG).show();
	   }
	
}
