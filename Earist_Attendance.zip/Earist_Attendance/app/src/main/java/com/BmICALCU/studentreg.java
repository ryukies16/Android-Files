package com.BmICALCU;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class studentreg extends Activity
{
	Button btnstudsub,btnstudcancel;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.student_reg);
		
		Button btnstudsub =findViewById(R.id.btnstudreg);
		Button btnstudcancel=findViewById(R.id.btnstudcancel);
		
		btnstudcancel.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent(studentreg.this,admin.class);
					startActivity(intent);
				}


			});
	}	
	public void Onsubstudent (View view){
		Toast.makeText(this,"Success Input",Toast.LENGTH_LONG).show();
	}
	
}
