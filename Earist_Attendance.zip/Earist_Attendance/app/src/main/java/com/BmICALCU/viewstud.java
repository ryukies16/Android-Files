package com.BmICALCU;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class viewstud extends Activity
{
  Button btnvstudsubmit;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewstud);
		
		Button btnvstudsubmit = findViewById(R.id.vstudsubmit)                  ;
		
		btnvstudsubmit.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent(viewstud.this,studentlist.class);
					startActivity(intent);
				}
				
			
		});
}
}
