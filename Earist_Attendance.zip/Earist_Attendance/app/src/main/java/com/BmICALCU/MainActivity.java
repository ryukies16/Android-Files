package com.BmICALCU;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;

public class MainActivity extends Activity
{
	Button loginbtn;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.main);
		Button loginbtn=findViewById(R.id.wcbtn);
		
		loginbtn.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent (MainActivity.this,login.class)                          ;
				     startActivity(intent);	
					}

		
	});
			
		
	}
	 
	 
 }

