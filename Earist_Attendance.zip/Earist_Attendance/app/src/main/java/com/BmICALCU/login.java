package com.BmICALCU;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class login extends Activity
{
	Button btn1;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		
		Button btn1 =findViewById(R.id.logbtn1);
		
		btn1.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent intent = new Intent (login.this,admin.class)                          ;
					startActivity(intent);	
				}


			});
	}
	
}
