package com.Exercisefive;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.widget.AdapterView.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity 
	{
		ListView listv;
		TextView txtv;

		String [] Mysing = {
				"Kisapmata","Manila"

			};

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.main);
				listv=findViewById(R.id.list1);
				ArrayAdapter<String> adapt= new ArrayAdapter<String>(this,R.layout.textviews,Mysing);
				listv.setAdapter(adapt);

				listv.setOnItemClickListener(new AdapterView.OnItemClickListener(){

							@Override
							public void onItemClick(AdapterView<?> parent, View view, int position, long id)
								{
									// TODO: Implement this method
									switch (position){
											case 0:
												Intent songone= new Intent(MainActivity.this,singone.class);
												startActivity(songone);
												break;

											case 1:
												Intent songtwo= new Intent(MainActivity.this,singtwo.class);
												startActivity(songtwo);
												break;





										}

								}


						});

			}
	}
