package com.Exer5SicatAnalyn;


import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.widget.AdapterView.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity 
	{
		ListView listv;
		TextView txtv;

		String [] myplaylist = {
				"i'd lie","Permanent Marker ","Style","Enchanted","Hey Stephen"

			};

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.main);
				listv=findViewById(R.id.list1);
				ArrayAdapter<String> adapt= new ArrayAdapter<String>(this,R.layout.textview,myplaylist);
				listv.setAdapter(adapt);

				listv.setOnItemClickListener(new AdapterView.OnItemClickListener(){

							@Override
							public void onItemClick(AdapterView<?> parent, View view, int position, long id)
								{
									// TODO: Implement this method
									switch (position){
											case 0:
												Intent songone= new Intent(MainActivity.this,sing_one.class);
												startActivity(songone);
												break;

											case 1:
												Intent songtwo= new Intent(MainActivity.this,sing_two.class);
												startActivity(songtwo);
												break;

											case 2:
												Intent songthree= new Intent(MainActivity.this,sing_three.class);
												startActivity(songthree);
												break;

											case 3:
												Intent songfour= new Intent(MainActivity.this,sing_four.class);
												startActivity(songfour);
												break;


											case 4:
												Intent songfive= new Intent(MainActivity.this,sing_five.class);
												startActivity(songfive);
												break;

										}

								}


						});

			}
	}
