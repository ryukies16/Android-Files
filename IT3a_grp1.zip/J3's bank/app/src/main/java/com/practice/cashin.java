package com.practice;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;

public class cashin extends Activity
	{
		ImageView palawans,cebuabas,tambuntings,touchpays,mlhuillers;
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.cash_in);
				
				palawans = findViewById(R.id.palawan);
				cebuabas = findViewById(R.id.cebuana);
				tambuntings = findViewById(R.id.tambunting);
				touchpays= findViewById(R.id.touchpay);
				mlhuillers = findViewById(R.id.mlhuiller);
				
				palawans.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashin.this,palawan.class);
									startActivity(intent);
								}
							
					
				});
				
				cebuabas.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashin.this,cebuana.class);
									startActivity(intent);
								}


						});
						
				tambuntings.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashin.this,tambunting.class);
									startActivity(intent);
								}


						});
						
				touchpays.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashin.this,touchpay.class);
									startActivity(intent);
								}


						});
						
				mlhuillers.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashin.this,mlhuiller.class);
									startActivity(intent);
								}


						});

			}
	}

