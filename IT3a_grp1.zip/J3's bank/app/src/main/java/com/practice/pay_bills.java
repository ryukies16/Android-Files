package com.practice;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import com.google.firebase.database.*;

public class pay_bills extends Activity
{
		ImageView cverge,mralco,mnilad;
		FirebaseDatabase bills = FirebaseDatabase.getInstance();
		DatabaseReference root = bills.getReference();
	
	
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.paybills);
				
				cverge=findViewById(R.id.converge);
				mralco=findViewById(R.id.meralco);
				mnilad=findViewById(R.id.maynilad)                                    ;

				mralco.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(pay_bills.this,meralco.class);
									startActivity(intent);
								}


						});
						
				cverge.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(pay_bills.this,converge.class);
									startActivity(intent);
								}


						});
				mnilad.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(pay_bills.this,maynilad.class);
									startActivity(intent);
								}


						});
				
}
}
