package com.practice;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import com.practice.*;

public class nconverge extends Activity
	{
		TextView nacc,nname,namount,nemail;
		Button nbtn;

		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.nconverge);

				nacc=findViewById(R.id.nconvergeaccnumber)                             ;
				nname=findViewById(R.id.nconvergename);
				namount=findViewById(R.id.nconvergeamount);
				nemail=findViewById(R.id.nconvergeemail);
				nbtn=findViewById(R.id.nconvergebutton);

				nacc.setText(getIntent().getStringExtra("key1"));
				nname.setText(getIntent().getStringExtra("key2"));
				namount.setText(getIntent().getStringExtra("key3"));
				nemail.setText(getIntent().getStringExtra("key4"));
				


			}
	}
