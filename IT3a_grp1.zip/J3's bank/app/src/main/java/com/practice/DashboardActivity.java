package com.practice;


import android.content.*;
import android.icu.text.*;
import android.os.*;
import android.preference.*;
import android.support.v7.app.*;
import android.view.*;
import android.widget.*;
import com.google.firebase.database.*;

public class DashboardActivity extends AppCompatActivity {
        float bal;
	    
		String EmailHolder;
		TextView Email, Balance;
		ImageView trans,bills,cin,cout,load;
		FirebaseDatabase db = FirebaseDatabase.getInstance();
		DatabaseReference dash = db.getReference().child("balance");
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.dashboard);
 
				trans = (ImageView)findViewById(R.id.transfer);
				bills = (ImageView)findViewById(R.id.bills);
				cin = (ImageView)findViewById(R.id.cashin);
				cout = (ImageView)findViewById(R.id.cashout);
				load = (ImageView)findViewById(R.id.buyload);
				Balance = (TextView)findViewById(R.id.balance)                                                       ;
				SharedPreferences share = PreferenceManager.getDefaultSharedPreferences(this);
				float total =share.getFloat("key1",0);
				int pcashin =share.getInt("palawan",1);
				float peso;
				float palawans;
				  
				bal =pcashin;
				Balance.setText(Float.toString(bal));
				
				peso = total - 10;
				DecimalFormat Peso = new DecimalFormat(" ###,###,###.##");
				Balance.setText(""+ Peso.format(peso));
				
				palawans = 10 - bal;
				DecimalFormat Palawan = new DecimalFormat(" ###,###,###.##");
				Balance.setText(""+ Palawan.format(palawans));
				
				trans.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									if(p1.equals(trans)){
									Intent intent = new Intent(DashboardActivity.this,ncashout.class);
									startActivity(intent);
									}
								}
							
					
				});
				
				bills.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,pay_bills.class);
									startActivity(intent);
								}


						});
						
				cin.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,cashin.class);
									startActivity(intent);
								}


						});
						
				cout.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,cashout.class);
									startActivity(intent);
								}


						});
						
				load.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,buyload.class);
									startActivity(intent);
								}


						});
						
						

			}


	}

