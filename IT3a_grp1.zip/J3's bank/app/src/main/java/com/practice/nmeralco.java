package com.practice;


import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;

public class nmeralco extends Activity
	{
		TextView nacc,nname,namount,nemail;
		Button nbtn;
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.nmeralco);
				
				nacc=findViewById(R.id.nmaccnumber)                             ;
				nname=findViewById(R.id.nmname);
				namount=findViewById(R.id.nmamount);
				nemail=findViewById(R.id.nmemail);
				nbtn=findViewById(R.id.nmbutton);
				
				nacc.setText(getIntent().getStringExtra("key1"));
				nname.setText(getIntent().getStringExtra("key2"));
				namount.setText(getIntent().getStringExtra("key3"));
				nemail.setText(getIntent().getStringExtra("key4"));
				





			}
	}
