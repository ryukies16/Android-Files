package com.practice;

import android.app.*;
import android.content.*;
import android.os.*;
import android.preference.*;
import android.view.*;
import android.widget.*;
import com.practice.*;

public class tambunting extends Activity
	{
		int pcashin;
		float total;
		float fee;

		EditText ped;
		TextView pfees,ptotal;
		Button pbutton;

		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.tambunting);

				ped =findViewById(R.id.tamount);
				pfees =findViewById(R.id.tfee);
				ptotal=findViewById(R.id.ttotalamount);
				pbutton=findViewById(R.id.tbtn)                                                                              ;




				final SharedPreferences share_palawan =PreferenceManager.getDefaultSharedPreferences(this);

				pbutton.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									pcashin = Integer.parseInt((ped.getText().toString()));

									if( pcashin <= 19){
											Toast.makeText(tambunting.this,"Amount must be least 20",Toast.LENGTH_LONG).show();
										}

									if(pcashin >= 20 && pcashin <= 99){

											fee = 10+10;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));
										}
									if(pcashin >= 100 && pcashin <= 499){

											fee = 5+5;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));
										}
									if(pcashin >= 500 && pcashin <= 1000){

											fee = 10+10;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));



										}

									if(pcashin >= 1001 && pcashin <= 2000){

											fee = 20+20;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));



										}
									if(pcashin >= 2001 && pcashin <= 3000){

											fee = 30+30;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));



										}

									if(pcashin >= 3001 && pcashin <= 5000){

											fee = 40+40;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));



										}
									if(pcashin >= 5001 && pcashin <= 10000){

											fee = 50+50;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));



										}
									if(pcashin >= 10001){

											fee = 30+30;
											pfees.setText(Float.toString(fee));
											total =pcashin+fee;
											ptotal.setText(Float.toString(total));



										}



								}



						});


			}
	}


