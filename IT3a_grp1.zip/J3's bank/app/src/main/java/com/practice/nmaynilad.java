package com.practice;


import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;

public class nmaynilad extends Activity
	{
		TextView nacc,nname,namount,nemail;
		Button nbtn;

		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.nmaynilad);

				nacc=findViewById(R.id.nmayniladaccnumber)                             ;
				nname=findViewById(R.id.nmayniladname);
				namount=findViewById(R.id.nmayniladamount);
				nemail=findViewById(R.id.nmaynilademail);
				nbtn=findViewById(R.id.nmayniladbutton);

				nacc.setText(getIntent().getStringExtra("key1"));
				nname.setText(getIntent().getStringExtra("key2"));
				namount.setText(getIntent().getStringExtra("key3"));
				nemail.setText(getIntent().getStringExtra("key4"));

				



			}
	}
