package com.practice;

import android.app.*;
import android.os.*;
import android.view.*;

public class nnmaynilad extends Activity
	{
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.nnmaynilad);
			}
	}
