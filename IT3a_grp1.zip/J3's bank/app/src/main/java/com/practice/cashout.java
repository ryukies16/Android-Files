package com.practice;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;

public class cashout  extends Activity
	{
		ImageView outspalawan,outstambunting,outscebuana,outstouchpay,outslhuiller;
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.cash_out);
				
				outspalawan = findViewById(R.id.outpalawan);
				outstambunting =findViewById(R.id.outtambunting);
				outscebuana = findViewById(R.id.outcebuana);
				outstouchpay =findViewById(R.id.outtouchpay);
				outslhuiller = findViewById(R.id.outmlhuiller);
				
				
				outspalawan.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
								Intent intent = new Intent(cashout.this,coutpalawan.class);
								startActivity(intent);
								}
							
					
					
				});
				
				outstambunting.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashout.this,couttambunting.class);
									startActivity(intent);
								}



						});
						
						
				outscebuana.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashout.this,coutcebuana.class);
									startActivity(intent);
								}



						});
						
				outslhuiller.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashout.this,coutmlhuiller.class);
									startActivity(intent);
								}



						});
						
				outstouchpay.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(cashout.this,couttouchpay.class);
									startActivity(intent);
								}



						});

			}
	}
