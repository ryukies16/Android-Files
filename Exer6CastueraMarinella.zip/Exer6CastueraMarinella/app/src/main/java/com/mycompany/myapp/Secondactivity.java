package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.preference.*;
import android.icu.text.*;

public class Secondactivity extends Activity
	{
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.second);
				TextView monthpay = findViewById(R.id.monthlypayment);
				ImageView img =findViewById(R.id.payment);
				SharedPreferences sharepref = PreferenceManager.getDefaultSharedPreferences(this)     ;
				int Intmonth = sharepref.getInt("key1",0);
				float cloan = sharepref.getFloat("key2",0);
				float mininterest = sharepref.getFloat("key3",0);
				float paymonth;


				paymonth = cloan/((Intmonth * mininterest)*100);
				DecimalFormat Peso = new DecimalFormat ("P###,###.##");
				monthpay.setText("Payment for Month"+ Peso.format(paymonth));
				if(Intmonth == 1){
						img.setImageResource(R.drawable.imgfirst);
					}
				else if (Intmonth == 2){
						img.setImageResource(R.drawable.imgsec);
					}
				else if (Intmonth == 3){
						img.setImageResource(R.drawable.imgthi);
					}
				else if (Intmonth == 4){
						img.setImageResource(R.drawable.imgfor);
					}
				else if (Intmonth == 5){
						img.setImageResource(R.drawable.imgfif);

					}
			}
	}
