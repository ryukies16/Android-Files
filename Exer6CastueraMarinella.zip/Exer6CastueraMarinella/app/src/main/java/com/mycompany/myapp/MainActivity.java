package com.mycompany.myapp;
import android.app.*;
import android.os.*;
import android.widget.*;
import java.time.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import android.preference.*;

public class MainActivity extends Activity 
	{
		int intyears;
		float intloan;
		float decinterest;
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.main);
				final EditText years = (EditText) findViewById(R.id.etyears);
				final EditText loan = (EditText) findViewById(R.id.etloan);
				final EditText interest = (EditText) findViewById(R.id.etinterest);
				Button button= (Button) findViewById(R.id.button);
				final SharedPreferences sharedpref = PreferenceManager.getDefaultSharedPreferences(this);
				button.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick(View v){
									intyears = Integer.parseInt(years.getText().toString());
									intloan = Float.parseFloat(loan.getText().toString());
									decinterest = Float.parseFloat(interest.getText().toString());
									SharedPreferences.Editor editor = sharedpref.edit();
									editor.putInt("key1",intyears);
									editor.putFloat("key2",intloan);
									editor.putFloat("key3",decinterest);
									editor.commit();
									startActivity(new Intent(MainActivity.this, Secondactivity.class));
								}
						});
			}

	}
