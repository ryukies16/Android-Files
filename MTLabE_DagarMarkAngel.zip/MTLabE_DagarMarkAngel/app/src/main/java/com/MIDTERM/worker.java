package com.MIDTERM;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class worker extends Activity 
	{
		EditText ed2,ed3,ed4;
		TextView total;
		Button btn;

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.worker);
                ed2 =findViewById(R.id.edtxt2);
				ed3 =findViewById(R.id.edtxt3);
				
				ed4=findViewById(R.id.edtxt4);
				total=findViewById(R.id.btntotal);
				btn=findViewById(R.id.totalfee);
				
				
				 

			}
	}
