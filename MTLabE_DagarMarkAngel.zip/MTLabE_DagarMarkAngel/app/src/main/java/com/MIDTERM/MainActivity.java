package com.MIDTERM;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity 
{
	Button btntotal,btnnext;
	TextView txttotal;
		EditText ed1,ed2,ed3;

		public void startActivities(Intent i)
			{
				// TODO: Implement this method
			}
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		
		btnnext = findViewById(R.id.btnext);
		
		
	     btntotal=findViewById(R.id.btntotal);
		txttotal =findViewById(R.id.totalfee);
		ed1 =findViewById(R.id.edtxt1);
		ed2 =findViewById(R.id.edtxt2);
		ed3 =findViewById(R.id.edtxt3);
		
		
		
		btntotal.setOnClickListener(new View.OnClickListener()
				{

					@Override
					public void onClick(View p1)
						{
							double average= Double.parseDouble(ed2.getText().toString())                ;
							double tuition = Double.parseDouble(ed3.getText().toString());
	
		
							if(average >= 95 && average <= 100){
								double dis = tuition-tuition;
								double total = dis - dis;
									txttotal.setText(String.valueOf(total));
								}
							if(average >= 90 && average <= 94){
									double dis = tuition-(tuition*0.25);
									double total = tuition - dis;
									txttotal.setText(String.valueOf(total));
									}
									if(average >= 85 && average <= 89){
											double dis = tuition-(tuition*.10);
											double total = tuition - dis;
											txttotal.setText(String.valueOf(total));
											}
											if(average <= 84){
													double dis = tuition;
													double total = tuition - dis;
													txttotal.setText(String.valueOf(total));
							}
						
							// TODO: Implement this method
						}
					
			
			
			
			
		});
		
		
					
			
			
		
		

		btnnext.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1)
						{
					Intent i = new Intent(MainActivity.this,worker.class);
					startActivity(i);
						}

				
				
			});
					
					
			
			
			
			
		
		
		}
    
}
