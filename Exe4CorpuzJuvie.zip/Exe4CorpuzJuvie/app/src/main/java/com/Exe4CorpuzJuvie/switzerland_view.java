package com.Exe4CorpuzJuvie;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class switzerland_view extends Activity
	{

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.switzerland);
			}
		public void onswitzerland (View view){
				Toast.makeText(this,"Switzerland is a mountainous Central European country, home to numerous lakes, villages and the high peaks of the Alps. Its cities contain medieval quarters, with landmarks like capital Bern’s Zytglogge clock tower and Lucerne’s wooden chapel bridge. The country is also known for its ski resorts and hiking trails. Banking and finance are key industries, and Swiss watches and chocolate are world renowned.",Toast.LENGTH_LONG).show()                     ;
			}



	}
