package com.Exe4CorpuzJuvie;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;

public class MainActivity extends Activity 
{
	ListView lview;
	String [] country ={" Manila "," Taiwan "," Canada ","  USA ","  Switzerland "};
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		lview = findViewById(R.id.listv);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.text_view,country);
		lview.setAdapter(adapter);
		
		lview.setOnItemClickListener(new AdapterView.OnItemClickListener(){

					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id)
						{
						switch(position){
							case 0:
							Intent manila = new  Intent (MainActivity.this,manila_view.class);
							startActivity(manila);
							break;
								case 1:
									Intent taiwan = new  Intent (MainActivity.this,taiwan_view.class);
									startActivity(taiwan);
									break;
								case 2:
									Intent canada = new  Intent (MainActivity.this,canada_view.class);
									startActivity(canada);
									break;
								case 3:
									Intent usa = new  Intent (MainActivity.this,usa_view.class);
									startActivity(usa);
									break;
								case 4:
									Intent switzerland = new  Intent (MainActivity.this,switzerland_view.class);
									startActivity(switzerland);
									break;
							
						}
				
						
						
							
						}

			
			
		});
	
    }
}
