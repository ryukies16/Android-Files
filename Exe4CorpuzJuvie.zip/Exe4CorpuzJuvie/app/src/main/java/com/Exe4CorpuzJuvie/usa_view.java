package com.Exe4CorpuzJuvie;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class usa_view extends Activity
	{

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.usa);
			}
		public void onusa (View view){
				Toast.makeText(this,"The U.S.A is a country of 50 states covering a vast swath of North America, with Alaska in the northwest and Hawaii extending the nation’s presence into the Pacific Ocean. Major Atlantic Coast cities are New York, a global finance and culture center, and capital Washington, DC. Midwestern metropolis Chicago is known for influential architecture and on the west coast, Los Angeles' Hollywood is famed for filmmaking.\"",Toast.LENGTH_LONG).show()                     ;
			}



	}
