package com.Exe4CorpuzJuvie;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class taiwan_view extends Activity
	{

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.taiwan);
			}
		public void ontaiwan (View view){
				Toast.makeText(this,"Taiwan, officially the Republic of China, is a country in East Asia. Neighbouring countries include the People's Republic of China to the northwest, Japan to the northeast, and the Philippines to the south.",Toast.LENGTH_LONG).show()                     ;
			}



	}
