package com.Exe4CorpuzJuvie;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class manila_view extends Activity
	{

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.manila);
			}
			 public void onmanila (View view){
				 Toast.makeText(this,"Manila, the capital of the Philippines, is a densely populated bayside city on the island of Luzon, which mixes Spanish colonial architecture with modern skyscrapers. Intramuros, a walled city in colonial times, is the heart of Old Manila. It’s home to the baroque 16th-century San Agustin Church as well as Fort Santiago, a storied citadel and former military prison.",Toast.LENGTH_LONG).show()                     ;
			 }
			 
			
	
}
