package com.Exe4CorpuzJuvie;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class canada_view extends Activity
	{

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.canada);
			}
		public void oncanada (View view){
				Toast.makeText(this,"Canada is a country in the northern part of North America. Its ten provinces and three territories extend from the Atlantic to the Pacific and northward into the Arctic Ocean, covering 9.98 million square kilometres, making it the world's second-largest country by total area",Toast.LENGTH_LONG).show()                     ;
			}



	}
