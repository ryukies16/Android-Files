package com.Exersice5;



import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.widget.AdapterView.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity 
	{
		ListView listv;
		TextView txtv;

		String [] my_favorite = {
				"This I Promise You"
			};

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.main);
				listv=findViewById(R.id.list1);
				txtv = findViewById(R.id.txt2);
				
				ArrayAdapter<String> adapt= new ArrayAdapter<String>(this,R.layout.txtview,my_favorite);
				listv.setAdapter(adapt);

				listv.setOnItemClickListener(new AdapterView.OnItemClickListener(){

							@Override
							public void onItemClick(AdapterView<?> parent, View view, int position, long id)
								{
									// TODO: Implement this method
									switch (position){
											case 0:
												Intent Firstsong= new Intent(MainActivity.this,first_song.class);
												startActivity(Firstsong);
												break;

						}

								}


						});

			}
	}
