

package com.Exe5BejerJenelyn;


import android.app.*;
import android.os.*;
import android.widget.*;
import android.widget.SearchView.*;
import android.view.View.*;
import android.widget.Button;
import android.widget.Toast;
import android.view.*;
import android.content.*;
import android.media.*;
import java.util.*;

public class song_two extends Activity implements MediaPlayer.OnPreparedListener
	{
		private Button btnplay;
		private MediaPlayer media;
		private SeekBar seekbar;
		private Timer time;
		private boolean prepared;
		private boolean changing;
		TextView tv;



		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.first_song);
				btnplay =(Button) findViewById(R.id.btnplay);
				seekbar = (SeekBar) findViewById(R.id.seekbar);
				tv =findViewById(R.id.txt2);
				tv.setSelected(true);

				media=MediaPlayer.create(getApplicationContext(),R.raw.song_second)                    ;
				seekbar.setMax(media.getDuration());

				prepared =false;
				time=new Timer();
				media.setOnPreparedListener(this);

				seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

							@Override
							public void onProgressChanged(SeekBar p1, int p2, boolean p3)
								{
									if(prepared && p3){
											media.seekTo(p2);
										}
									// TODO: Implement this method
								}

							@Override
							public void onStartTrackingTouch(SeekBar p1)
								{
									// TODO: Implement this method
								}

							@Override
							public void onStopTrackingTouch(SeekBar p1)
								{
									// TODO: Implement this method
								}



						});


				btnplay.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									if(!prepared)
										return;

									if(media.isPlaying()){
											media.pause();
											btnplay.setText("Play");
											time.cancel();
											time= new Timer();

										}
									else{
											media.start();
											btnplay.setText("Pause");
											time.schedule(new ProgressUpdate(),0,1000);
										}

								}
						});
			} 



		@Override
		protected void onPause()
			{
				// TODO: Implement this method
				super.onPause();
				//	btnplay.setOnClickListener(null);
			}
		public Handler mHandler = new Handler(){


				public void handleMessage(Message msg)
					{
						// TODO: Implement this method
						seekbar.setProgress(msg.arg1);
					}


			};

		@Override
		public void onPrepared(MediaPlayer p1)
			{
				prepared=true;
				// TODO: Implement this method
			}

		private class ProgressUpdate extends TimerTask
			{


				public ProgressUpdate()
					{
						super();
						// TODO: Implement this method
					}

				@Override
				public void run()
					{
						int current =media.getCurrentPosition();
						Message msg = new Message();
						msg.arg1=current;
						mHandler.dispatchMessage(msg);

						// TODO: Implement this method
					}




			}






	}
