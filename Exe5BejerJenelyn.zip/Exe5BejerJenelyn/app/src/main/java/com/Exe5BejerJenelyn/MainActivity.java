
package com.Exe5BejerJenelyn;

import android.app.*;
import android.os.* ;
import android.widget.*;
import android.view.*;
import android.widget.AdapterView.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity 
	{
		ListView listv;
		TextView txtv;

		String [] Mysongs = {
				"Mr.Right","12 Days Of Christmas","Stuck On You","If Life Is So Short","You're Still The One"
			};

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.main);
				listv=findViewById(R.id.list1);
				ArrayAdapter<String> adapt= new ArrayAdapter<String>(this,R.layout.textview,Mysongs);
				listv.setAdapter(adapt);

				listv.setOnItemClickListener(new AdapterView.OnItemClickListener(){

							@Override
							public void onItemClick(AdapterView<?> parent, View view, int position, long id)
								{
									// TODO: Implement this method
									switch (position){
											case 0:
												Intent Firstsong= new Intent(MainActivity.this,song_one.class);
												startActivity(Firstsong);
												break;

											case 1:
												Intent Second_song= new Intent(MainActivity.this,song_two.class);
												startActivity(Second_song);
												break;

											case 3:
												Intent Third_song= new Intent(MainActivity.this,song_three.class);
												startActivity(Third_song);
												break;


											case 4:
												Intent Fourt_song= new Intent(MainActivity.this,song_four.class);
												startActivity(Fourt_song);
												break;

											case 5:
												Intent Fifth_song= new Intent(MainActivity.this,song_five.class);
												startActivity(Fifth_song);
												break;
										}

								}


						});

			}
	}
