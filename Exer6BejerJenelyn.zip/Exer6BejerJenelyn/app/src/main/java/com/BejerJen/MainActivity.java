package com.BejerJen;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.preference.*;

public class MainActivity extends Activity
{
	int Intmonth;
    float cloan;
	float minterest;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		final EditText month =(EditText) findViewById(R.id.month);
		final EditText cash_loan =(EditText)findViewById(R.id.cloan);
		final EditText m_interest = (EditText)findViewById(R.id.minterest);
		final SharedPreferences SharedPref = PreferenceManager.getDefaultSharedPreferences(this);
		Button button =findViewById(R.id.buttonloan);
		
		button.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1)
						{
							Intmonth = Integer.parseInt(month.getText().toString())                ;
							cloan =Float.parseFloat(cash_loan.getText().toString());
							minterest =Float.parseFloat(m_interest.getText().toString());
							SharedPreferences.Editor editor = SharedPref.edit();
							editor.putInt("key1",Intmonth);
							editor.putFloat("key2",cloan);
							editor.putFloat("key3",minterest);
							editor.commit();
							startActivity(new Intent(MainActivity.this, secondact.class));
							
							
							// TODO: Implement this method
						}
					
			
		});
    }
}
