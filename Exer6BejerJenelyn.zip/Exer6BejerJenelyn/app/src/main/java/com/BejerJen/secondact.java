package com.BejerJen;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.preference.*;
import android.icu.text.*;

public class secondact extends Activity
{
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				setContentView(R.layout.second);
				TextView monthpay = findViewById(R.id.paymonth);
				ImageView imgone =findViewById(R.id.img1);
				SharedPreferences sharepref = PreferenceManager.getDefaultSharedPreferences(this)     ;
				int Intmonth = sharepref.getInt("key1",0);
				float cloan = sharepref.getFloat("key2",0);
				float mininterest = sharepref.getFloat("key3",0);
				float paymonth;
				
				
				paymonth = cloan/((Intmonth * mininterest)*100);
				DecimalFormat Peso = new DecimalFormat ("P###,###.##");
				monthpay.setText("Payment for Month"+ Peso.format(paymonth));
				if(Intmonth >0){
					imgone.setImageResource(R.drawable.houseloan);
				}
					
						
	}

}

