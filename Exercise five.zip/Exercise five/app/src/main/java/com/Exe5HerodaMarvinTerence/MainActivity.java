package com.Exe5HerodaMarvinTerence;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.widget.AdapterView.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity 
{
	ListView listv;
	TextView txtv;
	
	String [] worship_song = {
			" Lord I offer My Life to You"," Lord I give You My Heart"
		
	};
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		listv=findViewById(R.id.list1);
		ArrayAdapter<String> adapt= new ArrayAdapter<String>(this,R.layout.textv,worship_song);
	    listv.setAdapter(adapt);
		
		listv.setOnItemClickListener(new AdapterView.OnItemClickListener(){

					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id)
						{
							// TODO: Implement this method
							switch (position){
								case 0:
									Intent songone= new Intent(MainActivity.this,sing_one.class);
									startActivity(songone);
									break;
								
								case 1:
									Intent songtwo= new Intent(MainActivity.this,sing_two.class);
									startActivity(songtwo);
									break;
									
										
									
										
										
							}
							
						}
					
			
		});
	
    }
}
